import tensorflow as tf
from tensorflow.keras.optimizers import Adam
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix
import time,sys
import sqlite3
from sklearn.preprocessing import StandardScaler, Normalizer, label_binarize

from tensorflow import set_random_seed
set_random_seed(30)
np.random.seed(1337)
dbname = sys.argv[1]

random_seed = 1
training_ratio = 0.9
scorelist = []
x_sum_list = []
y_sum_list = []
familyindexlist = ["BitCoinMiner","ChinaZ","CornelGEN","Ddos","DnsAmp","Dofloo","Elknot","Flood","Flooder","Gafgyt","Ganiw","Mirai","Ramgo","Tsunami","Xorddos"]
y_sum_list_fold = []
# connect db
con = sqlite3.connect('database/'+dbname)
cursor = con.cursor()
cursor.execute("SELECT * FROM sampleparam")
con.commit()
MLrawdata = cursor.fetchall()

for data in MLrawdata:
	tmplist = []
	y_family_list = []
	familyname = data[22]
	ismal = data[23]
	for num in range(1,20):
		tmplist.append(float(data[num]))
	x_sum_list.append(tmplist)
	for index in range(0,len(familyindexlist)):
		if familyname == familyindexlist[index]:
			y_family_list.append(str(1))
		else:
			y_family_list.append(str(0))
	y_sum_list.append(y_family_list)
	y_sum_list_fold.append(ismal)
con.close()
# Load data
train_X = np.array(x_sum_list,np.float_)
train_Y = np.array(y_sum_list,np.int_)
train_Y_bin = np.array(y_sum_list_fold,np.int_)
# split data into training and testing
X_train, X_test, Y_train, Y_test = train_test_split(train_X, train_Y, test_size=1 - training_ratio, random_state=random_seed)

X_test = np.array(x_sum_list,np.float_)
Y_test =np.array(y_sum_list,np.int_)
print(len(X_test),",",len(Y_test))
y_GT = Y_test
X_train = np.expand_dims(X_train, axis=2)
X_test = np.expand_dims(X_test, axis=2)

model = tf.keras.models.Sequential()
model.add(
    tf.keras.layers.Conv1D(19, kernel_size=5, input_shape=(X_train.shape[1], 1), padding='same', activation='elu'))
model.add(tf.keras.layers.Conv1D(60, kernel_size=5, padding='same', activation='elu'))
model.add(tf.keras.layers.MaxPooling1D(2))
model.add(tf.keras.layers.Dropout(0.6))
model.add(tf.keras.layers.Flatten())
model.add(tf.keras.layers.Dense(40, activation='elu'))
model.add(tf.keras.layers.Dropout(0.6))
model.add(tf.keras.layers.Dense(30, activation='elu'))
model.add(tf.keras.layers.Dropout(0.6))
model.add(tf.keras.layers.Dense(2, activation='softmax'))

model.compile(loss=tf.keras.losses.categorical_crossentropy,
              optimizer=Adam(lr = 0.0001),
              metrics=['accuracy'])
s_time = time.time()
history = model.fit(X_train, Y_train,
                    batch_size=32,
                    epochs=20,
                    verbose=1,
                    validation_data=(X_test, Y_test),
                    )
e_time = time.time()
print('Took {} seconds'.format(e_time - s_time))
model.save('model/classification_model.h5')
print("classification model save finish")
score = model.evaluate(X_test, Y_test, verbose=1)
print(score)
