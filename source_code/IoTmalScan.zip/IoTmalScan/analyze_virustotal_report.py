
import os
import json
import subprocess
from operator import itemgetter

def main():
    rawtxtpath =  "VTReport/"
    rawpath = "training_sample/"
    AV_vendor = ["BitDefender","ESET-NOD32","MicroWorld-eScan"]
    #BitDefender ex: Gen:Variant.Backdoor.Linux.Gafgyt.1 ,Generic.Gafgyt.1.3BAFA3E4, Trojan.Linux.Backdoor.C, Linux.CornelGEN.1622, Linux.DnsAmp.C,Application.BitCoinMiner.AAD
    #  Trojan.Agent.BKXM = Linux.DDOS.Flood.I, Trojan.Agent.Linux.A, Generic.Malware.G!IFg.AAA2B793= Tsunami, Gen:Variant.Trojan.Linux.MrBlack.1=Dnsamp,Linux.Backdoor.I,Trojan.Elf.SIP
    #ESET        ex: a variant of Linux/Mirai.A, a variant of Linux/TrojanDownloader.Mirai.A, Linux/Agent.AE, Linux/Exploit.CVE-2013-2094.B
    #MicroWorld-eScan  ex: Gen:Variant.Backdoor.Linux.Gafgyt.1
    familylist = []
    yearsamplelist = []
    familydir = "malware_family/"
    dirname = ["BitCoinMiner","ChinaZ","CornelGEN","Ddos","DnsAmp","Dofloo","Elknot","Flood","Flooder","Gafgyt","Ganiw","Mirai","Ramgo","Tsunami","Xorddos"]
    AVrecordlist = []
    samplelist = os.listdir(rawtxtpath)
    latestfilelist = []
    for name in samplelist:
        with open(rawtxtpath+name, 'r+',encoding = 'UTF-8') as file:
            rawjson = json.load(file)
            rawdate = rawjson['first_seen']
            filtertime = rawdate.split()[0]
            year = int(filtertime.split("-")[0])
            if year > 2012:
                latestfilelist.append(name)
    commonlist = []  # record common sense family name and its sample name for finally mv it to resp. dir
    removecmd = "mv "
    
    finaljudgecount = 0
    for name in latestfilelist:  # name = xxx.txt samplelist->latestfilelist
        with open(rawtxtpath+name, 'r+',encoding = 'UTF-8') as file1:
            rawjson = json.load(file1)
            rawscan = rawjson['scans']
            rawdate = rawjson['first_seen']
            #print(rawdate)
            resultcount = 0
            judgelist = []
            for elem in rawscan:
                if elem == AV_vendor[0] or elem == AV_vendor[1] or elem == AV_vendor[2]:
                    if rawscan[elem]['detected'] == True:
                        resultcount += 1
                        #print(elem,":",rawscan[elem]['result']) 
                        if elem == "ESET-NOD32":
                            tmpfilter = rawscan[elem]['result'].split(".")[0]
                            tmpstring = tmpfilter.split("/")[-1]
                            if tmpstring == "Agent" and rawscan[elem]['result'].split(".")[1] == "AE":
                                tmpstring = "Ganiw"
                            elif "Downloader" in tmpstring:
                                tmpstring = rawscan[elem]['result'].split(".")[1]
                            elif rawscan[elem]['result'].split(".")[1] == "CVE-2013-2094":
                                tmpstring = "CornelGEN"
                            elif rawscan[elem]['result'].split(".")[1] == "Shark":
                                tmpstring = "Shark"
                            #print("ESET:",tmpstring)
                        elif elem == "BitDefender":
                            if len(rawscan[elem]['result'].split(".")) == 5:
                                tmpstring = rawscan[elem]['result'].split(".")[-2]
                                if tmpstring == "MrBlack":
                                    tmpstring = "DnsAmp"
                            elif len(rawscan[elem]['result'].split(".")) == 4:
                                if len(rawscan[elem]['result'].split(".")[2]) == 1:
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                                elif rawscan[elem]['result'].split(".")[2] == "Linux":
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                                elif rawscan[elem]['result'].split(".")[2] == "G!IFg":
                                    tmpstring = "Tsunami"
                                elif rawscan[elem]['result'].split(".")[2] == "G!I!Fg":
                                    tmpstring = "Tsunami"
                                else:
                                    tmpstring = rawscan[elem]['result'].split(".")[2]
                            elif len(rawscan[elem]['result'].split(".")) == 3:
                                if rawscan[elem]['result'].split(".")[1] == "Elf":
                                    tmpstring = "Unknown"
                                elif rawscan[elem]['result'].split(".")[2] == "BKXM":
                                    tmpstring = "ChinaZ"
                                else:
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                            #print("Bit:",tmpstring)
                        elif elem == "MicroWorld-eScan":
                            if len(rawscan[elem]['result'].split(".")) == 5:
                                tmpstring = rawscan[elem]['result'].split(".")[-2]
                                if tmpstring == "MrBlack":
                                    tmpstring = "DnsAmp"
                            elif len(rawscan[elem]['result'].split(".")) == 4:
                                if len(rawscan[elem]['result'].split(".")[2]) == 1:
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                                elif rawscan[elem]['result'].split(".")[2] == "Linux":
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                                elif rawscan[elem]['result'].split(".")[2] == "G!IFg":
                                    tmpstring = "Tsunami"
                                elif rawscan[elem]['result'].split(".")[2] == "G!I!Fg":
                                    tmpstring = "Tsunami"
                                else:
                                    tmpstring = rawscan[elem]['result'].split(".")[2]
                            elif len(rawscan[elem]['result'].split(".")) == 3:
                                if rawscan[elem]['result'].split(".")[1] == "Elf":
                                    tmpstring = "Unknown"
                                elif rawscan[elem]['result'].split(".")[2] == "BIXD":
                                    tmpstring = "Xorddos"
                                elif rawscan[elem]['result'].split(".")[2] == "BKXM":
                                    tmpstring = "ChinaZ"
                                else:
                                    tmpstring = rawscan[elem]['result'].split(".")[1]
                            #print("micro:",tmpstring)
                        
                        if len(judgelist) == 0:
                            if tmpstring != "":
                                judgelist.append([tmpstring,1])
                        else:
                            judgeflag = 0
                            for item in judgelist:
                                if item[0].lower() == tmpstring.lower():
                                    item[1] += 1
                                    judgeflag = 1
                                    break
                                elif item[0].lower() in tmpstring.lower():
                                    item[1] += 1
                                    judgeflag = 1
                                    break
                                elif tmpstring.lower() in item[0].lower():
                                    item[1] += 1
                                    judgeflag = 1
                                    break
                            if judgeflag == 0:
                                if tmpstring != "":
                                    judgelist.append([tmpstring,1])
            if resultcount == 3:
                if len(judgelist) == 1:
                    if judgelist[0][1] == 3:   # imply the same family of all vendor
                        #print("true")
                        finaljudgecount +=1
                        filtertime = rawdate.split()[0]
                        year = int(filtertime.split("-")[0])
                        if year > 2012:    # yearsamplelist = [[familyname1,year1,name1],[]...]
                            commonlist = addfamily(judgelist[0][0],name[:-4],commonlist) # add to commonlist
                            if len(yearsamplelist) == 0:
                                yearsamplelist.append([judgelist[0][0],year,name])
                            else:
                                malfamilyflag = 0
                                yearflag = 0
                                for age in yearsamplelist:
                                    if age[0].lower() == judgelist[0][0].lower():
                                        malfamilyflag = 1
                                        if age[1] == year:
                                            age.append(name)
                                            yearflag = 1
                                            break
                                if malfamilyflag == 0:     # no this family
                                    yearsamplelist.append([judgelist[0][0],year,name])
                                else:
                                    if yearflag == 0:      # has family no this year
                                        yearsamplelist.append([judgelist[0][0],year,name])
                        if len(familylist) == 0:
                            familylist.append([judgelist[0][0],1,name])
                            # familylist = [[familyname,amount,sample1,sample2...],[]...]
                        else:
                            familyflag = 0
                            for familyname in familylist:
                                if familyname[0].lower() == judgelist[0][0].lower():
                                    familyname[1] += 1
                                    familyname.append(name)
                                    familyflag = 1
                                    break
                            if familyflag == 0:
                                familylist.append([judgelist[0][0],1,name])
                
    # commonlist = [[familyname1,filename1,filename2],[familyname2,...]...]
    if len(commonlist) == 0:
        print("There is some error in summary familylist for mv process")
    else:
        # merge different length or name family to one match dirname
        for family in commonlist:   # family=[familyname,filename1,filename2...]
            status = False
            if family[0] == "DoS" or family[0].lower() == "dos" or family[0] == "AESDdoS" or family[0].lower() == "aesddos":
                family[0] = "Ddos"
            elif family[0] == "MiraiDDoS" or family[0].lower() == "miraiddos":
                family[0] = "Mirai"
            elif family[0] == "Miner" or family[0].lower() == "miner" or family[0] == "CoinMiner" or family[0].lower() == "coinminer":
                family[0] = "BitCoinMiner"
            for famdir in dirname:  # confirm familyname dir exist or not
                if famdir.lower() == family[0].lower():
                    if family[0] != famdir:
                        family[0] = famdir
                    status = os.path.isdir(familydir+famdir)
                    if status == True:
                        break
            if status == True:       # family dir exist , move sample
                for i in range(1,len(family)):
                    if family[0] == "ChinaZ":
                        print(family[i]," ,",os.path.isfile(familydir+family[0]+"/"+family[i]))   
                    retcode = subprocess.run(removecmd+rawpath+family[i]+" "+familydir+family[0]+"/"+family[i],stdout=subprocess.PIPE, shell=True)
            #        print(removecmd+rawpath+family[i]+" "+familydir+family[0]+"/"+family[i])
    AVrecordlist.append([AV_vendor[0],AV_vendor[1],AV_vendor[2],finaljudgecount])
    sortedyearlist = sorted(yearsamplelist,key=itemgetter(0,1),reverse = True)
    for data in sortedyearlist:
        print(data[0]+"("+str(data[1])+"):",len(data)-2)
    print(finaljudgecount)
    sortedAVrecordlist = sorted(AVrecordlist,key=itemgetter(3),reverse = True)
    
    

def addfamily(familyname,samplename,recordlist):
    commonlist = recordlist    # recordlist = [[familyname1,filename1,filename2],[familyname2,...]...]
    family = familyname
    name = samplename
    if len(commonlist) == 0:
        commonlist.append([family,name])
    else:
        familyflag = 0
        for inner in commonlist:
            if inner[0].lower() == family.lower():
                familyflag = 1
                inner.append(name)
                break
        if familyflag == 0:
            commonlist.append([family,name])
    return commonlist
    

if __name__ == "__main__":
    main()
