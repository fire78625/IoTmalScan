
import subprocess
import sqlite3
import sys
import os

def count(samplename):                 # name = xxx.asm count
    name = samplename.split(".")[0]  # use when multi-file process in future
    #samplename = name+".asm"
    print(samplename)
    targetpath = "/home/owen/Desktop/CZNIC_search_sample/"
    asmpath = "/home/owen/Desktop/asmfile/"
    errorcount = 0
    recordlist = []
#------------------ISA list = [x86_64,80386(x86),MIPS,ARM,SPARC,PowerPC,m68k,Renesas_SH]-----------------    
    ISAlist = ["x86-64","386","MIPS","ARM","SPARC","PowerPC","Motorola m68k","Renesas_SH"] 
    #con = sqlite3.connect('/home/owen/Desktop/thirdparty.db')   # modify path
    #cursor = con.cursor()
    #cursor.execute("UPDATE sampleparam set op1 = '1' where name= '"+name+"'")
    #con.commit()
    #con.close()
    """# usage for multiple samples in file
    sampledir = str(subprocess.check_output("ls "+targetpath+dirname+"/", shell=True)).split("\\n")
    samplelist = []                         # record multi-samplename in list => samplelist = [sample1,sample2,...]
    for i in range(0,len(sampledir)-1):
        if i == 0:
            samplelist.append(sampledir[0].replace("b'",""))
        else:
            samplelist.append(sampledir[i])
    """
#for loop to get filename and ISA relation
    print(asmpath+samplename)
    # testisapath -> asmpath ; testfilename -> name
    outfile = open(asmpath+samplename,'r+',encoding = "latin1")
    fileformat = ""
    for tmpline in outfile:
        if "Format " in tmpline and "Executable" in tmpline:
            tmpformat = tmpline.split()
            num = 0
            for ele in range(0,len(tmpformat)):
                if "for" == tmpformat[ele]:
                    num = ele + 1
                    if "Intel" == tmpformat[ele+1]:
                        num = ele + 2
            fileformat = tmpformat[num]
    if fileformat == "SuperH":
        fileformat = "Renesas_SH"
    if fileformat == "Motorola":
        fileformat = "Motorola m68k"
    outfile.close()
    isaflag = 0
    for isa in ISAlist:
        if isa == fileformat:
            isaflag = 1
    if isaflag == 0:
        fileformat = "Unknown"
    isaindex = isaParam(fileformat)
    if fileformat == "Unknown":
        recordlist.append([samplename,10])
    else:            
        recordlist.append([samplename,isaindex]) # recordlist=[[filename1,isaindex],[filename2,isaindex]]
    #print(recordlist) #test
#------ format get success ------
    
    funnamelist = []         # funnamelist = [[funname1,op1,op2,..],[funname2,op1,op2,...]...]
    #for loop to summary each asm.file 
    if isaindex == 2:        # 80386
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile1 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile1:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0:                 # check for fun. start (cond: proc)
                #if line != "\n" and line[0] != ";" and line[0] != "\t":
                #print(line.split("\t"))
                if line != "\n" and line[0] != ";" and line[0] != "\t":
                    sepline = line.split("\t")
                    for ele in sepline:
                        if "proc" in ele:
                            if "near" in ele:
                                startflag = 1
                                if "proc" in sepline[0]:
                                    resepfun = sepline[0].split()
                                    funnamelist.append([resepfun[0]])
                                    funname = resepfun[0]
                                    #print(resepfun[0])
                                else:
                                    funnamelist.append([sepline[0]])
                                    funname = sepline[0]
                                    #print(sepline[0])
                    if "fini" in sepline[0]:
                        if "ends" in line:
                            routinendflag = 1
                            break
                    
            elif routineflag == 1 and startflag == 1:                 #[start,end] = [1,0],[1,1]
                if line != "\n" and ":" not in line.split("\t")[0] and line[0] != ";" and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    #print(filterlist)
                    if "endp" in line: 
                        endflag = 1
                    else:
                        if len(opcodelist) == 0:
                            opcodelist.append([filterlist[0],1])
                            #print(filterlist[0])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                                    #print("afterlist=",item)
                        elif "arg" in filterlist[0] or "addr" in filterlist[0] or "var" in filterlist[0] or "= dword" in line or "= qword" in line:
                            errorcount += 1  # wrong_op
                        elif ";" in filterlist[0] or "dup" in line or "align" in line:
                            errorcount += 1  # error comment
                        else:
                            #print(filterlist[0])
                            opflag = 0
                            for op in opcodelist:
                                if op[0] == filterlist[0]:
                                    op[1] += 1
                                    opflag = 1
                                    break
                            if opflag == 0:
                                opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                #print(item)
                                if item[0] == funname:
                                    if "\n" in filterlist[0]:
                                        replaceret = filterlist[0].replace("\n","")
                                        if "rep" in replaceret:
                                            reopcode = replaceret.split()
                                            item.append(reopcode[1])
                                        else:
                                            item.append(replaceret)
                                    elif "align" not in filterlist[0]:
                                        item.append(filterlist[0])
                                    #print("afterlist=",item)
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        # start to summary opcodes
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile1.close()        
    
    if isaindex == 1:   # x64
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile2 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile2:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0:                 # check for fun. start (cond: proc)
                if line != "\n" and line[0] != ";" and line[0] != "\t":
                    sepline = line.split("\t")
                    for ele in sepline:
                        if "proc" in ele:
                            if "near" in ele:
                                startflag = 1
                                if "proc" in sepline[0]:
                                    resepfun = sepline[0].split()
                                    funnamelist.append([resepfun[0]])
                                    funname = resepfun[0]
                                    #print(resepfun[0])
                                else:
                                    funnamelist.append([sepline[0]])
                                    funname = sepline[0]
                                    #print(sepline[0])
                    if "align" in sepline[0]:
                        errorcount += 1
                    if "fini" in sepline[0]:
                        if "ends" in line:
                            routinendflag = 1
                            break
            elif routineflag == 1 and startflag == 1:                 #[start,end] = [1,0],[1,1]
                if line != "\n" and ":" not in line.split("\t")[0] and line[0] != ";" and "align" not in line and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    if "endp" in line: 
                        endflag = 1
                    else:
                        if len(opcodelist) == 0:
                            opcodelist.append([filterlist[0],1])
                            #print(filterlist[0])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                                    #print("afterlist=",item)
                        elif "arg" in filterlist[0] or "addr" in filterlist[0] or "var" in filterlist[0] or "= dword" in line or "= qword" in line:
                            errorcount += 1  # wrong_op
                        elif ";" in filterlist[0]:
                            errorcount += 1  # error comment
                        else:
                            #print(filterlist[0])
                            opflag = 0
                            for op in opcodelist:
                                if op[0] == filterlist[0]:
                                    op[1] += 1
                                    opflag = 1
                                    break
                            if opflag == 0:
                                opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                #print(item)
                                if item[0] == funname:
                                    if "\n" in filterlist[0]:
                                        replaceret = filterlist[0].replace("\n","")
                                        if "rep" in replaceret:
                                            reopcode = replaceret.split()
                                            item.append(reopcode[1])
                                        else:
                                            item.append(replaceret)
                                    elif "align" not in filterlist[0]:
                                        item.append(filterlist[0])
                                    #print("afterlist=",item)
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        # start to summary opcodes
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile2.close()
    if isaindex == 3:  # MIPS
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile3 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile3:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B R O U T I N E" in line and routineflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0:                 # check for fun. start (cond: proc)
                if "XREF" in line:
                    tmpfun = line.split("\t")
                    if "loc_" not in tmpfun[0] and "locret" not in tmpfun[0] and "hlt" not in tmpfun[0]:
                        #print(tmpfun[0][:-1])
                        funnamelist.append([tmpfun[0][:-1]])
                        funname = tmpfun[0][:-1]
                        startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line and line != "\n" and line[0] != "\t":
                    #print(line.split()[0][:-1])
                    funnamelist.append([line.split()[0][:-1]])
                    funname = line.split()[0][:-1]
                    startflag = 1                    
            elif routineflag == 1 and startflag == 1:
                if line != "\n" and ":" not in line.split("\t")[0] and line[0] != ";" and "-" not in line and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    if "End of function" in line:
                        endflag = 1
                        #print("fun_end")
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            routinendflag = 1
                            break                   
                    if len(opcodelist) == 0:
                        if len(filterlist) == 1 and "#" not in filterlist[0]:
                            refilstr = filterlist[0].replace("\n","")
                            opcodelist.append([refilstr,1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(refilstr)
                        else:
                            if "#" not in filterlist[0]:
                                opcodelist.append([filterlist[0],1])
                                #print(filterlist[0])
                                for item in funnamelist:
                                    if item[0] == funname:
                                        item.append(filterlist[0])
                                #print("afterlist=",item)
                    elif "arg" in filterlist[0] or "addr" in filterlist[0] or "var" in filterlist[0] or "= dword" in line or "= qword" in line:
                        errorcount += 1  # wrong_op
                    elif "#" in line and "End of function" not in line and "$" not in line:
                        errorcount += 1
                    elif ";" in filterlist[0]:
                        errorcount += 1  # error comment
                    elif "#" not in filterlist[0] and "_" not in filterlist[0]:
                        #print(filterlist[0])
                        opflag = 0
                        for op in opcodelist:
                            if op[0] == filterlist[0]:
                                op[1] += 1
                                opflag = 1
                                break
                        if opflag == 0:
                            opcodelist.append([filterlist[0],1])
                        for item in funnamelist:
                            #print(item)
                            if item[0] == funname:
                                if "\n" in filterlist[0]:
                                    #print()
                                    replaceret = filterlist[0].replace("\n","")
                                    if "rep" in replaceret:
                                        reopcode = replaceret.split()
                                        item.append(reopcode[1])
                                    else:
                                        item.append(replaceret)
                                elif "align" not in filterlist[0]:
                                    item.append(filterlist[0])
                                #print("afterlist=",item)
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0        
        #for opcodelist in funnamelist:
        #    print(opcodelist)
                    
        outfile3.close()
    if isaindex == 4:  # ARM
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile4 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile4:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0 and routinendflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0 and routinendflag == 0: # check for fun. start (cond: proc)                
                if "XREF" in line and "loc_" not in line.split()[0] and "off" not in line.split("\t")[0] and "dword" not in line and "src" not in line and "aProt_" not in line.split("\t")[0] and "aHttp1_" not in line.split("\t")[0] and "DCD" not in line:
                    tmpfun = line.split("\t")
                    #print(tmpfun[0])
                    funnamelist.append([tmpfun[0]])
                    funname = tmpfun[0]
                    startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line.split()[0] and line.split("\t")[0] != "":
                    #print(line.split("\t")[0])
                    if "\n" in line.split("\t")[0]:
                        resetstr = line.split("\t")[0].replace("\n","")
                        funnamelist.append([resetstr])
                        funname = resetstr
                        startflag = 1
                    else:
                        funnamelist.append([line.split("\t")[0]])
                        funname = line.split("\t")[0]
                        startflag = 1     
            elif routineflag == 1 and startflag == 1 and routinendflag == 0:
                if line != "\n" and line.split("\t")[0] != ";" and "-" not in line and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    #print(filterlist)
                    if "End of function" in line:
                        endflag = 1
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            print("end section")
                            routinendflag = 1
                            break
                    if len(opcodelist) == 0:
                        if len(filterlist) == 1 and "text" not in line.split("\t")[-1] and "DCB" not in filterlist[0]:
                            refilstr = filterlist[0].replace("\n","")
                            #print(refilstr)
                            opcodelist.append([refilstr,1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(refilstr)
                        else:
                            if "#" not in filterlist[0] and "text" not in line.split("\t")[-1] and "DCB" not in filterlist[0] and "DCD" in filterlist[0] and "ALIGN" in filterlist[0]:
                                opcodelist.append([filterlist[0],1])
                                #print(filterlist[0])
                                for item in funnamelist:
                                    if item[0] == funname:
                                        item.append(filterlist[0])
                    elif "arg" in filterlist[0] or "addr" in filterlist[0] or "var" in filterlist[0] or "= dword" in line or "dword" in line.split()[0] or "= qword" in line:
                        errorcount += 1
                    elif "End of function" in line and ";" in filterlist[0] and "DCB" in filterlist[0] and "DCD" in filterlist[0] and "ALIGN" in filterlist[0]:
                        errorcount += 1
                    elif "loc_" not in line and ";" not in line.split("\t")[-1]:
                        #print(filterlist[0])
                        if "..." not in line:
                            opflag = 0
                            for op in opcodelist:
                                if op[0] == filterlist[0]:
                                    op[1] += 1
                                    opflag = 1
                                    break
                            if opflag == 0:
                                opcodelist.append([filterlist[0],1])
                            elif "__div0" == funname:
                                opcodelist.append(["RET",1])
                            elif "memmove" == funname:
                                opcodelist.append(["B",1])
                            for item in funnamelist:
                                #print(item)
                                if item[0] == funname:
                                    if "\n" in filterlist[0]:
                                        #print()
                                        replaceret = filterlist[0].replace("\n","")
                                        if "rep" in replaceret:
                                            reopcode = replaceret.split()
                                            if len(reopcode) > 1:
                                                item.append(reopcode[1])
                                        else:
                                            item.append(replaceret)
                                    elif "align" not in filterlist[0]:
                                        item.append(filterlist[0])
                                    elif item[0] == "__div0":
                                        item.append("RET")
                                    elif item[0] == "memmove":
                                        item.append("B")                        
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0        
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile4.close()
    if isaindex == 5:  # SPARC
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile5 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile5:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0 and routinendflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0 and routinendflag == 0: # check for fun. start (cond: proc)                
                if "XREF" in line and "loc_" not in line.split()[0] and "off" not in line and "dword" not in line and "src" not in line and "locret_" not in line.split()[0]:
                    tmpfun = line.split("\t")
                    #print(tmpfun[0])
                    funnamelist.append([tmpfun[0][:-1]])
                    funname = tmpfun[0][:-1]
                    startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line.split()[0] and line.split("\t")[0] != "":
                    #print(line.split("\t")[0])
                    if "\n" in line.split("\t")[0]:
                        resetstr = line.split("\t")[0].replace("\n","")
                        funnamelist.append([resetstr[:-1]])
                        funname = resetstr[:-1]
                        startflag = 1                    
            elif routineflag == 1 and startflag == 1 and routinendflag == 0:
                if line != "\n" and line.split("\t")[0] != ";" and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    if "End of function" in line:
                        endflag = 1
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            print("end section")
                            routinendflag = 1
                            break
                    if len(opcodelist) == 0:
                        #print(filterlist)
                        if len(filterlist) == 1:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                        else:
                            if "\n" in filterlist[0]:
                                refilstr = filterlist[0].replace("\n","")
                                opcodelist.append([refilstr,1])
                                for item in funnamelist:
                                    if item[0] == funname:
                                        item.append(refilstr)
                            else:
                                opcodelist.append([filterlist[0],1])
                                #print(filterlist[0])
                                for item in funnamelist:
                                    if item[0] == funname:
                                        item.append(filterlist[0])                               
                    elif "var" in filterlist[0] or "arg" in filterlist[0]:
                        errorcount += 1
                    elif "!" in line and "End of function" not in line:
                        errorcount += 1
                    elif len(filterlist) == 1 and "End of function" not in line:
                        if "\n" in filterlist[0]:
                            replaceret = filterlist[0].replace("\n","")
                            #print(replaceret)
                            opcodelist.append([replaceret,1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(replaceret)
                    elif "End of function" in line:
                        errorcount += 1
                    elif "loc_" not in filterlist[0] and "locret_" not in filterlist[0] and "XREF" not in line and "CHUNK" not in line and "..." not in line and "inet_aton" not in line.split()[-1]:
                        opflag = 0
                        for op in opcodelist:
                            if op[0] == filterlist[0]:
                                op[1] += 1
                                opflag = 1
                                break
                        if opflag == 0:
                            opcodelist.append([filterlist[0],1])                        
                        for item in funnamelist:
                            #print(item)
                            if item[0] == funname:
                                if "\n" in filterlist[0]:
                                    #print()
                                    replaceret = filterlist[0].replace("\n","")
                                    if "rep" in replaceret:
                                        reopcode = replaceret.split()
                                        item.append(reopcode[1])
                                    else:
                                        item.append(replaceret)
                                elif "align" not in filterlist[0]:
                                    item.append(filterlist[0])
                                                
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile5.close()
    if isaindex == 6: # PowerPC
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile6 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile6:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0 and routinendflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0 and routinendflag == 0:
                if "XREF" in line and "loc_" not in line.split()[0] and "off" not in line and "dword" not in line and "locret_" not in line.split()[0]:
                    tmpfun = line.split("\t")
                    #print(tmpfun[0])
                    funnamelist.append([tmpfun[0][:-1]])
                    funname = tmpfun[0][:-1]
                    startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line.split()[0]:
                    #print(line.split("\t")[0])
                    if "\n" in line.split("\t")[0]:
                        resetstr = line.split("\t")[0].replace("\n","")
                        funnamelist.append([resetstr[:-1]])
                        funname = resetstr[:-1]
                        startflag = 1
                    else:
                        funnamelist.append([line.split("\t")[0][:-1]])
                        funname = line.split("\t")[0][:-1]
                        startflag = 1                        
            elif routineflag == 1 and startflag == 1 and routinendflag == 0:
                if line != "\n" and line.split("\t")[0] != ";" and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    #print(filterlist)
                    if "End of function" in line:
                        endflag = 1
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            print("end section")
                            routinendflag = 1
                            break
                    if len(opcodelist) == 0 and "set" not in line.split()[0]:
                        if len(filterlist) == 1:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                        else:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                    elif "End of function" in line:
                        errorcount += 1
                    elif len(filterlist[0]) == 1:
                        #print(filterlist)
                        if "\n" in filterlist[0]:
                            replaceret = filterlist[0].replace("\n","")
                            #print(replaceret)
                            opcodelist.append([replaceret,1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(replaceret)
                        else:
                            #print(filterlist[0])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                    elif "loc_" not in filterlist[0] and "set" in filterlist[0]:
                        errorcount += 1
                    elif len(filterlist) == 1:
                        if "#" not in filterlist[0] and "long" not in filterlist[0] and "globl" not in filterlist[0]:
                            replaceret = filterlist[0].replace("\n","")
                            #print(replaceret)
                            opcodelist.append([replaceret,1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(replaceret)
                    elif "loc_" not in filterlist[0] and "locret_" not in filterlist[0] and "#" not in filterlist[0] and "dword" not in filterlist[0] and "init" not in filterlist[0] and "def_" not in filterlist[0]:
                        #print(filterlist[0])
                        opflag = 0
                        for op in opcodelist:
                            if op[0] == filterlist[0]:
                                op[1] += 1
                                opflag = 1
                                break
                        if opflag == 0:
                            opcodelist.append([filterlist[0],1])
                        
                        for item in funnamelist:
                            #print(item)
                            if item[0] == funname:
                                if "\n" in filterlist[0]:
                                    #print()
                                    replaceret = filterlist[0].replace("\n","")
                                    if "rep" in replaceret:
                                        reopcode = replaceret.split()
                                        item.append(reopcode[1])
                                    else:
                                        item.append(replaceret)
                                elif "align" not in filterlist[0]:
                                    item.append(filterlist[0])
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile6.close()
    if isaindex == 7: #Motorola m68k
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile7 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile7:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0 and routinendflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0 and routinendflag == 0:
                #print(line.split())
                if "XREF" in line and "loc_" not in line.split()[0] and "off" not in line and "dword" not in line and "locret_" not in line.split()[0]:
                    tmpfun = line.split("\t")
                    #print(tmpfun[0])
                    funnamelist.append([tmpfun[0][:-1]])
                    funname = tmpfun[0][:-1]
                    startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line.split()[0] and ":" in line.split()[0]:
                    #print(line.split("\t")[0])
                    if "\n" in line.split("\t")[0]:
                        resetstr = line.split("\t")[0].replace("\n","")
                        funnamelist.append([resetstr[:-1]])
                        funname = resetstr[:-1]
                        startflag = 1
                    else:
                        funnamelist.append([line.split("\t")[0][:-1]])
                        funname = line.split("\t")[0][:-1]
                        startflag = 1
            elif routineflag == 1 and startflag == 1 and routinendflag == 0:
                if line != "\n" and line.split("\t")[0] != ";" and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    #print(filterlist)
                    if "End of function" in line:
                        endflag = 1
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            print("end section")
                            routinendflag = 1
                            break
                    elif funname == "abort" and "S U B	R O U T	I N E" in line:
                        endflag = 1
                    if len(opcodelist) == 0 :
                        if len(filterlist) == 1:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                        else:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                    elif "End of function" in line:
                        errorcount += 1
                    elif len(filterlist) == 1 and ";" not in filterlist[0] and "dc" not in filterlist[0] and "fintrz" not in filterlist[0] and "global" not in filterlist[0]:
                        replaceret = filterlist[0].replace("\n","")
                        #print(replaceret)
                        opcodelist.append([replaceret,1])
                        for item in funnamelist:
                            if item[0] == funname:
                                item.append(replaceret)
                    elif "loc_" not in filterlist[0] and "var_" not in filterlist[0] and "arg_" not in filterlist[0] and ";" not in filterlist[0] and "dc" not in filterlist[0] and "word_" not in filterlist[0] and "fintrz" not in filterlist[0]:
                        if "$" in filterlist[0]:
                            filterlist[0] = line.split()[0]
                        #print(filterlist[0])
                        opflag = 0
                        for op in opcodelist:
                            if op[0] == filterlist[0]:
                                op[1] += 1
                                opflag = 1
                                break
                        if opflag == 0:
                            opcodelist.append([filterlist[0],1])
                            
                        for item in funnamelist:
                            #print(item)
                            if item[0] == funname:
                                if "\n" in filterlist[0]:
                                    #print()
                                    replaceret = filterlist[0].replace("\n","")
                                    if "rep" in replaceret:
                                        reopcode = replaceret.split()
                                        item.append(reopcode[1])
                                    else:
                                        item.append(replaceret)
                                elif "align" not in filterlist[0]:
                                    item.append(filterlist[0])                        
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile7.close()
    if isaindex == 8: # Renesas_SH
        opcodelist = []      # opcodelist = [[opcode1,count1],[opcode2,count2],...]
        outfile8 = open(asmpath+samplename,'r+',encoding = "latin1")
        routineflag = 0      # for mark the opcode section start or not
        startflag = 0        # for mark the function opcode start or not
        endflag = 0          # for mark the function opcode finish or not
        routinendflag = 0
        funname = ""
        for line in outfile8:  # [startflag,endflag]=[0,0],[1,0],[1,1]
            if "S U B	R O U T	I N E" in line and routineflag == 0 and routinendflag == 0: # check for opcode section start
                routineflag = 1
            elif routineflag == 1 and startflag == 0 and routinendflag == 0:
                #print(line.split())
                if "XREF" in line and "loc_" not in line.split()[0] and "off_" not in line and "word_" not in line and "locret_" not in line.split()[0] and "L_" not in line.split()[0] and "export" not in line.split()[0] and line[0] != "\t":
                    tmpfun = line.split("\t")
                    #print(tmpfun[0])
                    funnamelist.append([tmpfun[0][:-1]])
                    funname = tmpfun[0][:-1]
                    startflag = 1
                elif len(line.split()) == 1 and "loc_" not in line.split()[0] and ":" in line.split()[0] and "export" not in line.split()[0]:
                    #print(line.split("\t")[0])
                    if "\n" in line.split("\t")[0]:
                        resetstr = line.split("\t")[0].replace("\n","")
                        funnamelist.append([resetstr[:-1]])
                        funname = resetstr[:-1]
                        startflag = 1
                    else:
                        funnamelist.append([line.split("\t")[0][:-1]])
                        funname = line.split("\t")[0][:-1]
                        startflag = 1
            elif routineflag == 1 and startflag == 1 and routinendflag == 0:
                if line != "\n" and line.split("\t")[0] != ";" and endflag == 0:
                    filterlist = opflt(line)             # filterlist = [opcode, if exist[operand1,...]]
                    #print(filterlist)
                    if "End of function" in line:
                        endflag = 1
                        tmpline = line.split()
                        if "term_proc" in tmpline[-1]:
                            print("end section")
                            routinendflag = 1
                            break
                    elif funname == "exit" and "S U B	R O U T	I N E" in line:
                        endflag = 1
                    elif funname == "__uClibc_main" and "S U B	R O U T	I N E" in line:
                        endflag = 1
                    elif funname == "vfork" and "---" in line:
                        endflag = 1
                    elif funname == "main" and "S U B	R O U T	I N E" in line:
                        endflag = 1
                    elif funname == "processCmd" and "S U B	R O U T	I N E" in line:
                        endflag = 1
                    if len(opcodelist) == 0 :
                        if len(filterlist) == 1:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                        else:
                            #print(filterlist[0])
                            opcodelist.append([filterlist[0],1])
                            for item in funnamelist:
                                if item[0] == funname:
                                    item.append(filterlist[0])
                    elif "End of function" in line:
                        errorcount += 1
                    elif len(filterlist) == 1 and ";" not in filterlist[0] and "align" not in filterlist[0] and "datab" not in filterlist[0]:
                        replaceret = filterlist[0].replace("\n","")
                        #print(replaceret)
                        opcodelist.append([replaceret,1])
                        for item in funnamelist:
                            if item[0] == funname:
                                item.append(replaceret)
                    elif "loc_" not in filterlist[0] and ";" not in filterlist[0] and "off_" not in filterlist[0] and "word_" not in filterlist[0] and "var" not in filterlist[0] and "align" not in filterlist[0] and "def" not in filterlist[0] and "data" not in filterlist[0] and "jpt" not in filterlist[0]:
                        #print(filterlist[0])
                        opflag = 0
                        for op in opcodelist:
                            if op[0] == filterlist[0]:
                                op[1] += 1
                                opflag = 1
                                break
                        if opflag == 0:
                            opcodelist.append([filterlist[0],1])
                            
                        for item in funnamelist:
                            #print(item)
                            if item[0] == funname:
                                if "\n" in filterlist[0]:
                                    #print()
                                    replaceret = filterlist[0].replace("\n","")
                                    if "rep" in replaceret:
                                        reopcode = replaceret.split()
                                        item.append(reopcode[1])
                                    else:
                                        item.append(replaceret)
                                elif "align" not in filterlist[0]:
                                    item.append(filterlist[0])
                elif line == "\n" and endflag == 1:
                    #print("endtest")
                    startflag = 0
                    endflag = 0
        #for opcodelist in funnamelist:
        #    print(opcodelist)
        outfile8.close()        
####  ready to summarize
    totalnumcount = []
    totalnum = 0
    #for datat in funnamelist:
    #    print(datat)
    totalnumcount = opcodedist(funnamelist)   # totalnumcount = [1,2,3,4,5,6,7,8,9,10,11,12]
    totalratio = [0,0,0,0,0,0,0,0,0,0,0,0]
    for num in totalnumcount:
        totalnum += num
    for index in range(0,len(totalnumcount)):
        if totalnum == 0:
            ratio = 0
        else:
            ratio = round((float(totalnumcount[index]) / totalnum),2)
        totalratio[index] = str(ratio)
        #cursor.execute("UPDATE sampleparam set op"+str(index+1)+" = '"+str(ratio)+"' where name= '"+name+"'")
        #con.commit()
        print("update op"+str(index+1)+" success")
    #con.close()
    #print(totalratio)
    return totalratio
    

def opcodedist(originlist):    # originlist = [[fun1,op1,op2...],[fun2,op1,op2...]...]  op can be the same
    oplist = originlist
    oprecordlist = []          # oprecordlist = [[op1,amount1],[op2,amount2],...]
    counttypelist = [0,0,0,0,0,0,0,0,0,0,0,0]
    for opcode in oplist:      # opcode = [fun1,op1,op2...]
        for i in range(1,len(opcode)):
            if i == 1:
                if len(oprecordlist) == 0:
                    oprecordlist.append([opcode[1],1])
                else:
                    existflag = 0
                    for data in oprecordlist:   # data = [opname, times]
                        if opcode[1] == data[0]:
                            data[1] += 1
                            existflag = 1
                            break
                    if existflag == 0:
                        oprecordlist.append([opcode[1],1])
            else:
                existflag = 0
                for data in oprecordlist:   # data = [opname, times]
                    if opcode[i] == data[0]:
                        data[1] += 1
                        existflag = 1
                        break
                if existflag == 0:
                    oprecordlist.append([opcode[i],1])
    #print(oprecordlist)
    # ready for summary opcode
    packedoplist = []
    logicop = ["or","and","xor","nor","eor","orr","bic","orn","rev","xnor","flush","crand","creqv","crn","cror","crxor","ori","xori","eor","eori","clr","ori to ccr","andi to ccr"]
    controlstatus = ["test","com","comis","cmpxchg","salc","cmp","slt","cmn","cbz","tst","teq","casa","casxa","fcmp","dcb","tas","sett","dt","btst","bchg","bset","chk","scc","dbcc","vac","vcg","cbnz"]
    memory = ["mov","xchg","lea","les","lds","aa","lw","sb","sh","sw","lh","lb","ldc","mrc","mrs","fmov","prefetch","rd","restore","swap","wr","lfq","lmw","lswi","lwarx","mfsrin","mtsrin","sts","ld","st","move","move to ccr","move from sr","usp","exg","mvn","load","ldr","adr","bfc","bfi","mar","msr","vbi","vld"]
    stack = ["push","pop","enter","fdecstp","fincstp","bound","srs","stc","stm","str","vst","pea","link","unlk","rtr"]
    procedure = ["call","int","into","sysenter","sysexit","icebp","leave","syscall","break","hvc","smc","svc","sc"]
    prefix = ["es","cs","ds","fs","gs","lock","rep"]
    inout = ["in","out","ins","out","lods","stos","fstp",]
    arithmetic = ["add","adc","sub","rol","shl","div","mult","sra","sll","srl","sbc","rsb","asr","ror","subcc","fabs","fito","fneg","abs","cal","cau","fctiw","rlwimi","rlwnm","slw","sraw","srw","mac","rot","shl","ext","neg","mul","lsl","lsr","rsc","rrx","clz","mla","mia","mls","vml","vshr","sasx","sxt","ubfx","fsqrt","fsto"]
    system = ["arpl","hlt","sys","t","ti","illegal","trap","reset","stop","trapv"]
    branch = ["je","jn","retn","loop","iret","b","bl","bx","eret","rfe","return","fbx","done","bpr","bicc","jmpl","bc","bcctr","bclr","jmp","bra","jsr","bsrf","bf","bt","rte","rts","jsr","jmp","bra","bsr","bcc","beq","bne","jr","jal","j","bgez","bgtz","blez","bpcc","fbfcc","fbpcc","br"]
    exectime = ["wait","fwait","wfi","wfe"]
    #others = []   show for reminder 
    packedoplist.append(logicop)
    packedoplist.append(controlstatus)
    packedoplist.append(memory)
    packedoplist.append(stack)
    packedoplist.append(procedure)
    packedoplist.append(prefix)
    packedoplist.append(inout)
    packedoplist.append(arithmetic)
    packedoplist.append(system)
    packedoplist.append(branch)
    packedoplist.append(exectime)
    
    for op in oprecordlist:  # op = [opname,amount]
        existflag = 0
        for order in range(0,len(packedoplist)):  # order = logicop = memory = ...
            for elem in packedoplist[order]:               # elem = opcode
                #print(op)
                if elem.lower() == op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
                    break
            if order == 0 and existflag == 0:
                if "or" in op[0].lower() or "and" in op[0].lower() or "xor" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 1 and existflag == 0:
                if "cmp" in op[0].lower() or "test" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 2 and existflag == 0:
                if "mov" in op[0].lower() or "sw" in op[0].lower() or "sb" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 3 and existflag == 0:
                if "push" in op[0].lower() or "pop" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 4 and existflag == 0:
                if "call" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 7 and existflag == 0:
                if "add" in op[0].lower() or "sub" in op[0].lower() or "mul" in op[0].lower() or "div" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            elif order == 10 and existflag == 0:
                if "wait" in op[0].lower():
                    counttypelist[order] += op[1]
                    existflag = 1
            if existflag == 1:
                break
        if existflag == 0:
            counttypelist[11] += op[1]
    print(counttypelist)
    return counttypelist
    

def opflt(line):
    rawline = line
    #print(rawline)
    dividelist = rawline.split("\t")
    filist = list(filter(notempty,dividelist))
    return filist
    
def notempty(str1):
    return str1 and str1.strip()
    
def isaParam(fileformat):
    name = fileformat
    if "x86-64" in name:
        return 1
    elif "386" in name:
        return 2
    elif "MIPS" in name:
        return 3
    elif "ARM" in name:
        return 4
    elif "SPARC" in name:
        return 5
    elif "PowerPC" in name:
        return 6
    elif "Motorola m68k" in name:
        return 7
    elif "Renesas_SH" in name:
        return 8
    else:
        return 9

if __name__ == "__main__":
    main()
