
import r2pipe
import sys
import time
import os
import sqlite3
import hashlib
import subprocess
import autoisa_opcodestatics as autoop
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import load_model
from operator import itemgetter
from sklearn.preprocessing import StandardScaler, Normalizer, label_binarize

def main():
# basic setting and variable
    samplename = sys.argv[1]                        # samplename = new test sample name = hashvalue.extname
    targetpath = "sample/"
    elfutilspath = sys.argv[2]
    if os.path.isdir(elfutilspath):
        toolspath = elfutilspath
    else:
        print(elfutilspath," is not a directory")
    idapath = sys.argv[3]
    if not os.path.isdir(idapath):
        print(idapath, "is not a directory")
# external command
    filesizecmd = "ls -l "
    ISAcmd = "file "
    Packercmd = "yara rules/Packers_index.yar "
    extlibrarycmd = "ldd "
    funamountcmd = "afl | wc -l"
    stringscmd = "strings -a "
    funlistcmd = "afl "
    filterIPcmd = " | grep -v \"_\" | grep \"[0-9]\\{1,3\\}\\.[0-9]\\{1,3\\}\\.[0-9]\\{1,3\\}\\.[0-9]\\{1,3\\}\""
    filterDomaincmd = " | grep \"http://\\|https://\""
    
# other need list
    networklist = ["http","HTTP","UDP","TCP","FTP","STD","ioctl","send","connectTimeout","initConnection"]
    yaraAbilitylist = ["Antidebug_AntiVM_index.yar ","Crypto_index.yar ","CVE_Rules_index.yar ","email_index.yar ","Exploit-Kits_index.yar ","Malicious_Documents_index.yar ","utils_index.yar ","Webshells_index.yar ","gen_powershell_susp.yar ","gen_suspicious_strings.yar ","gen_susp_strings_in_ole.yar "]
    paramlist = []    # should only contain 1 data for upload [[param1,param2,...param23]]
    yaramatchlist = []
    familyindexlist = ["BitCoinMiner","ChinaZ","CornelGEN","Ddos","DnsAmp","Dofloo","Elknot","Flood","Flooder","Gafgyt","Ganiw","Mirai","Ramgo","Tsunami","Xorddos"]
    returnlist = []   # sha256, ismal, (optional: familyname or "benign")
# hash compute
    sha256hash = hashlib.sha256()
    with open(targetpath+samplename,'rb') as openfile:
        for byte_block in iter(lambda: openfile.read(4096),b""):        
            sha256hash.update(byte_block)
    sha256 = sha256hash.hexdigest()
    print("sha256=",sha256)
# start for static analysis about upload sample
    # packer
    Packerlist = []   # Packerlist = [[packer1,sum1=1],[packer2,sum2=1]...]
    packercount = 0
    repackresult = subprocess.run(Packercmd+targetpath+samplename,stdout=subprocess.PIPE, shell=True)
    packresult = str(repackresult.stdout).split("\\n")
    if len(packresult) > 0:
        if "b''" != packresult[0]:
            paramlist.append([samplename,"1","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","1","0","Unknown","0"])
            for k in range(0,len(packresult)-1):
                if k == 0:
                    packsplit = packresult[0].split()
                    if len(Packerlist) == 0:
                        Packerlist.append([packsplit[0].replace("b'",""),1])
                    else:                         # not use for 1 sample
                        packerflag = 0
                        for tmppack in Packerlist:
                            if tmppack[0] == packsplit[0].replace("b'",""):
                                tmppack[1] += 1
                                packerflag = 1
                                break
                        if packerflag == 0:
                            Packerlist.append([packsplit[0].replace("b'",""),1])
                else:
                    packerflag = 0
                    packsplit = packresult[k].split()
                    for tmppack in Packerlist:
                        if tmppack[0] == packsplit[0]:
                            tmppack[1] += 1
                            packerflag = 1
                            break
                    if packerflag == 0:
                        Packerlist.append([packsplit[0],1])
        else:
            paramlist.append([samplename,"0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","1","0","Unknown","0"])
    if len(Packerlist) == 0:
        print("There is no pack in samples")
    else:
        sortedpackerlist = sorted(Packerlist,key=itemgetter(1),reverse = True)
        print("sample used Packers:")
        for num in range(0,len(sortedpackerlist)):
            print(sortedpackerlist[num][0],":",sortedpackerlist[num][1])
    # ISA
    ISAlist = []
    rawheader = subprocess.run(ISAcmd+targetpath+samplename,stdout=subprocess.PIPE,shell=True)
    header = str(rawheader.stdout).split(", ")
    ISAlist.append([header[1],1])
    if len(paramlist) == 0:
        print("error in packer step")
    else:
        for data in paramlist:
            insert = str(checkisa(header[1]))
            data[2] = insert
    print("ISA:",header[1])
    # file size
    sizeresult = str(subprocess.check_output(filesizecmd+targetpath+samplename, shell=True))
    splitsize = sizeresult.split()
    samplesize = float(splitsize[4])/1024
    index = switchcase(samplesize)
    if index == 15:
        print("There has error about sample size process")
    else:
        for sizedata in paramlist:
            sizedata[3] = str(index)
    print("size:",samplesize)
    # function amount & network function (radare2)    
    r2 = r2pipe.open(targetpath+samplename)
    r2.cmd('aaa')
    amount = r2.cmd(funamountcmd)         # fun amount sum
    point = amountcase(int(amount))
    for funamount in paramlist:
        if point == 0:
            funamount[4] = str(1)
        elif point < 5:
            funamount[4] = str(2)
        elif point < 8:
            funamount[4] = str(3)
        elif point == 10:
            print("There has error in function amount process because of returning default value")
        else:
            print("Unknown error in fun amount r2 process")
    print("function amount:",amount)
    
    funlist = []
    funflag = 0                           # funflag shows the result of network protocol string
    rawfunstring = r2.cmd(funlistcmd)     # fun name list
    filterlist = rawfunstring.split("0x")
    del filterlist[0]
    for item in filterlist:
        rawlist = item.split()
        funlist.append(rawlist[-1])
    for func in funlist:
        for network in networklist:
            if network in func:
                funflag += 1
    if funflag > 0:
        print("exist network fun")
    # external library calling
    librarylist = []          # librarylist = [[library1,num1],[library2,num2],...]
    nodynamiccount = 0
    rawexlibresult = subprocess.run(extlibrarycmd+targetpath+samplename,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
    exlibresult = str(rawexlibresult.stdout).split("\\n\\t")
    if "not a dynamic executable" in str(rawexlibresult.stdout):
        nodynamiccount += 1
    elif exlibresult[0] == "b''":
        nodynamiccount += 1
    elif "unknown exit code" in str(rawexlibresult.stderr):
        nodynamiccount += 1
    else:
        if len(exlibresult) > 0:
            print(str(rawexlibresult))
            for exlibdata in paramlist:
                exlibdata[5] = str(1)
        for lib in exlibresult:
            if "b'" in lib:
                if len(librarylist) == 0:
                    librarylist.append([lib.split()[0].replace("b'\\t",""),1])
                else:
                    libflag = 0
                    for libceil in librarylist:
                        if libceil[0] == lib.split()[0].replace("b'\\t",""):
                            libceil[1] += 1
                            libflag = 1
                            break
                    if libflag == 0:
                        librarylist.append([lib.split()[0].replace("b'\\t",""),1])
            elif "=>" not in lib:
                tmpstring = lib.split()[0]
                tmplib = tmpstring.split("/")[-1]
                libflag = 0
                for libceil in librarylist:
                    if libceil[0] == tmplib:
                        libceil[1] += 1
                        libflag = 1
                        break
                if libflag == 0:
                    librarylist.append([tmplib,1])
            else:
                libflag = 0
                for libceil in librarylist:
                    if libceil[0] == lib.split()[0]:
                        libceil[1] += 1
                        libflag = 1
                        break
                if libflag == 0:
                    librarylist.append([lib.split()[0],1])
    print("library:")
    if len(librarylist) == 0:
        print("There is no external library call in samples")
    else:
        sortedlibrarylist = sorted(librarylist,key=itemgetter(1),reverse = True)
        for exlib in sortedlibrarylist:
            print(exlib[0]+": ",exlib[1])
    # network ability
    networksamplelist = []
    stringflag = 0
    ipreturn = subprocess.run(toolspath+stringscmd+targetpath+samplename+filterIPcmd,stdout=subprocess.PIPE, shell=True)
    reipreturn = str(ipreturn.stdout).split("\\n")
    if len(reipreturn) > 1 and reipreturn[0] != "b''":
        stringflag += 1
    domainreturn = subprocess.run(toolspath+stringscmd+targetpath+samplename+filterDomaincmd,stdout=subprocess.PIPE, shell=True)
    redomainreturn = str(domainreturn.stdout).split("\\n")
    if len(redomainreturn) > 1 and redomainreturn[0] != "b''":
        stringflag += 1
    if stringflag > 0:
        print("exist network string")
    if stringflag > 0 and funflag > 0:
        print("This sample has network ability")
        networksamplelist.append(samplename)
        for netability in paramlist:
            netability[6] = str(1)
        print("network trying:","True")
    elif stringflag > 0 and funflag == 0:
        print("There is no network fun")
    elif stringflag == 0 and funflag > 0:
        print("There is no network string")
    else:
        print("There is no any network string or fun")
    # other ability (with yara rules)
    antiVMlist = []
    antiVMcount = 0
    antisamplelist = []
    antiretlist = repeatedyaramodule(yaraAbilitylist[0],samplename)
    antiVMlist = antiretlist[0]
    antiVMcount = antiretlist[1]
    antisamplelist = antiretlist[2]
    yaramatchlist.append(antisamplelist)
    if len(antiVMlist) == 0:
        print("There is no antiVM ability yararules")
    else:
        print("antiVM :","True")
    
    cryptolist = []
    cryptocount = 0
    cryptosamplelist = []
    cryptoretlist = repeatedyaramodule(yaraAbilitylist[1],samplename)
    cryptolist = cryptoretlist[0]
    cryptocount = cryptoretlist[1]
    cryptosamplelist = cryptoretlist[2]
    yaramatchlist.append(cryptosamplelist)
    if len(cryptolist) == 0:
        print("There is no encrypted samples via yararules")
    else:
        print("encrypt :","True")
    
    CVElist = []
    CVEcount = 0
    CVEsamplelist = []
    CVEretlist = repeatedyaramodule(yaraAbilitylist[2],samplename)
    #CVEretlist = repeatedyaramodule(yaraAbilitylist[2],samplelist,dirname)
    CVElist = CVEretlist[0]
    CVEcount = CVEretlist[1]
    CVEsamplelist = CVEretlist[2]
    yaramatchlist.append(CVEsamplelist)
    if len(CVElist) == 0:
        print("There is no CVElist 2010~2018 via yararules")
    else:
        print("CVE list :","True")
    
    emaillist = []
    emailcount = 0
    emailsamplelist = []
    emailretlist = repeatedyaramodule(yaraAbilitylist[3],samplename)
    emaillist = emailretlist[0]
    emailcount = emailretlist[1]
    emailsamplelist = emailretlist[2]
    yaramatchlist.append(emailsamplelist)
    if len(emaillist) == 0:
        print("There is no email related yararules")
    else:
        print("email related :","True")
    
    Exploitlist = []
    Exploitcount = 0
    Exploitsamplelist = []
    Exploitretlist = repeatedyaramodule(yaraAbilitylist[4],samplename)
    Exploitlist = Exploitretlist[0]
    Exploitcount = Exploitretlist[1]
    Exploitsamplelist = Exploitretlist[2]
    yaramatchlist.append(Exploitsamplelist)
    if len(Exploitlist) == 0:
        print("There is no known exploit-kits via yararules")
    else:
        print("Exploit-kits :","True")
    
    maldocumentlist = []
    maldocumentcount = 0
    maldocumentsamplelist = []
    maldocretlist = repeatedyaramodule(yaraAbilitylist[5],samplename)
    maldocumentlist = maldocretlist[0]
    maldocumentcount = maldocretlist[1]
    maldocumentsamplelist = maldocretlist[2]
    yaramatchlist.append(maldocumentsamplelist)
    if len(maldocumentlist) == 0:
        print("There is no known mal-document via yararules")
    else:
        print("maldocument :","True")
    
    utilslist = []
    utilscount = 0
    utilsamplelist = []
    utilsretlist = repeatedyaramodule(yaraAbilitylist[6],samplename)
    utilslist = utilsretlist[0]
    utilscount = utilsretlist[1]
    utilsamplelist = utilsretlist[2]
    yaramatchlist.append(utilsamplelist)
    if len(utilslist) == 0:
        print("There is no web-related via yararules")
    else:
        print("(utils)web-related :","True")
    
    webshelllist = []
    webshellcount = 0
    webshellsamplelist = []
    webshellretlist = repeatedyaramodule(yaraAbilitylist[7],samplename)
    webshelllist = webshellretlist[0]
    webshellcount = webshellretlist[1]
    webshellsamplelist = webshellretlist[2]
    yaramatchlist.append(webshellsamplelist)
    if len(webshelllist) == 0:
        print("There is no webshell via yararules")
    else:
        print("webshell :","True")
    
    otherlist = []
    othercount = 0
    othersamplelist = []
    otherretlist = repeatedyaramodule(yaraAbilitylist[8],samplename)    
    tmpretlist1 = repeatedyaramodule(yaraAbilitylist[9],samplename)
    tmpretlist2 = repeatedyaramodule(yaraAbilitylist[10],samplename)
    otherlist = otherretlist[0]
    otherlist.extend(tmpretlist1[0])
    otherlist.extend(tmpretlist2[0])
    othercount = otherretlist[1] + tmpretlist1[1] + tmpretlist2[1]
    othersamplelist = otherretlist[2]
    othersamplelist.extend(tmpretlist1[2])
    othersamplelist.extend(tmpretlist2[2])
    yaramatchlist.append(othersamplelist)
    if len(otherlist) == 0:
        print("There is no other ability in remain yararules")
    else:
        print("others :","True")
    mixmatchlist = []
    for elem in yaramatchlist:
        if len(mixmatchlist) == 0:
            for name in elem:
                mixmatchlist.append([name,1])
        else:
            for name in elem:
                existflag = 0
                for mixelement in mixmatchlist:
                    if mixelement[0] == name:
                        mixelement[1] += 1
                        existflag = 1
                        break
                if existflag == 0:
                    mixmatchlist.append([name,1])
    solocount = 0
    doublecount = 0
    triplecount = 0
    fourthcount = 0
    extracount = 0
    for owability in paramlist:                   # paramlist=[[param1,...](,[param1...],[]...)]
        for inner in mixmatchlist:
            if inner[1] == 1:
                solocount += 1          
                owability[7] = str(1)            
                print("update yara_ability1")
            elif inner[1] == 2:
                doublecount += 1
                owability[7] = str(2)           
                print("update yara_ability2")
            elif inner[1] == 3:
                triplecount += 1
                owability[7] = str(3)            
                print("update yara_ability3")
            elif inner[1] == 4:
                fourthcount += 1
                owability[7] = str(4)            
                print("update yara_ability4")
            elif inner[1] > 4:
                extracount += 1
                owability[7] = str(5)            
                print("update yara_ability5")
    print("paramlist (before opcode)=",paramlist)
# opcode analysis   !!!samplename = xxx.extname
    
    asmpath = "asmfile/"
    tmppath = "tmpida/"
    idacmd = idapath+"idaq64 -c -B "
    opcoderesult = []                                    # opcoderesult = [op1,op2,op3...op12]
    # check /tmp/ida , if xxx.dmp exist, ida will block in reminder message. so delete file first
    if os.path.isdir("/tmp/ida/") == False:
        os.mkdir("/tmp/ida")
    sampledir = str(subprocess.check_output("ls /tmp/ida/", shell=True)).split("\\n")
    samplelist = []
    if len(sampledir) > 1:
        for i in range(0,len(sampledir)-1):
            if i == 0:
                samplelist.append(sampledir[0].replace("b'",""))
            else:
                samplelist.append(sampledir[i])
    for filename in samplelist:
        if "dmp" in filename:
            subprocess.run("rm /tmp/ida/"+filename,stdout=subprocess.PIPE,shell=True)
    
    idaresult = subprocess.run(idacmd+targetpath+samplename+" -o"+tmppath,stdout=subprocess.PIPE,shell=True)
    print(idaresult)
    if idaresult.returncode == 0:
        print("success")
    else:
        return "error"
    orifilename = samplename.split(".")[0]        # orifilename = xxx
    print("ori-filename:",orifilename)
    subprocess.run("rm "+tmppath+orifilename+".i64",stdout=subprocess.PIPE,shell=True)
    subprocess.run("mv "+tmppath+orifilename+".asm "+asmpath,stdout=subprocess.PIPE,shell=True)
    print("assembly file generate success")
    opcoderesult = autoop.count(orifilename+".asm")  #!!! modify function name
    
    print("generate opcode count success,result=",opcoderesult)
    for opcode in paramlist:                             # opcoderesult[0-11] = opcode[8-19] , paramlist = [[1st ELF parameter](,[2nd ELF parameter]...)]
        for i in range(8,20):
            opcode[i] = opcoderesult[i-8]    
    ### input model and transform parameter to X-test
    model = load_model('model/detection_model.h5')        # modify model name | import detection model from here
    x_sum_list = []
    print("load detection model success")
    for fixlist in paramlist:                            # paramlist should only contain 1 element (single-thread)
        tmplist = []
        for num in range(1,20):
            tmplist.append(float(fixlist[num]))
        x_sum_list.append(tmplist)
    print("original x_test=",x_sum_list)
    test_X = np.array(x_sum_list,np.float_)
    test_X = np.expand_dims(test_X, axis=2)
    print("after process xtest=",test_X)
    from sklearn.metrics import roc_curve, auc, precision_recall_fscore_support
    from tensorflow.keras import backend as K
    y_pred = model.predict_classes(test_X)              # y_pred = [{0,1}], if multiple, = [{0,1},{0,1},...]
    print("y-pred=",y_pred)
    
    if y_pred[0] == 0:
        returnlist.append(sha256)
        returnlist.append("0")
        returnlist.append("benign")
        print("detection benign")
        paramlist[0][23] = "0"
        paramlist[0][22] = "benign"
    elif y_pred[0] == 1:
        K.clear_session()                                        # avoid session exception occurs (although not affect execution result)
        classifymodel = load_model('model/classification_model.h5') # modify model name
        y_classify_pred = classifymodel.predict_classes(test_X)
        print(y_classify_pred)
        classifyindex = np.argmax(y_classify_pred)
        returnlist.append(sha256)
        returnlist.append("1")
        returnlist.append(familyindexlist[y_classify_pred[classifyindex]])
        print("detection malware, family=",familyindexlist[y_classify_pred[classifyindex]])
        paramlist[0][23] = "1"
        paramlist[0][22] = familyindexlist[y_classify_pred[classifyindex]]
    print("returnlist=",returnlist)                      # returnlist = [sha256,{0,1},{familyname,benign}]
    
    return returnlist

def switchcase(size):
    samplesize = size
    indexnum = 15
    if samplesize < 20:
        indexnum = 1
    elif samplesize < 40:
        indexnum = 2
    elif samplesize < 60:
        indexnum = 3
    elif samplesize < 80:
        indexnum = 4
    elif samplesize < 100:
        indexnum = 5
    elif samplesize < 120:
        indexnum = 6
    elif samplesize < 140:
        indexnum = 7
    elif samplesize < 160:
        indexnum = 8
    elif samplesize < 180:
        indexnum = 9
    elif samplesize < 200:
        indexnum = 10
    elif samplesize < 600:
        indexnum = 11
    elif samplesize < 1000:
        indexnum = 12
    elif samplesize < 1500:
        indexnum = 13
    else:
        indexnum = 14
    return indexnum

def checkisa(isaname):  #"80386","ARM","MIPS","x86-64","SPARC","PowerPC","Renesas","Motorola m68k"
    name = isaname
    if "80386" in name:
        return 1
    elif "ARM" in name:
        return 2
    elif "MIPS" in name:
        return 3
    elif "x86-64" in name:
        return 4
    elif "SPARC" in name:
        return 5
    elif "PowerPC" in name:
        return 6
    elif "Renesas" in name:
        return 7
    elif "Motorola" in name:
        return 8
    else:
        return 9

def amountcase(amount):
    num = amount
    index = 10
    if num < 50:
        index = 0
    elif num < 100:
        index = 1
    elif num < 150:
        index = 2
    elif num < 200:
        index = 3
    elif num < 250:
        index = 4
    elif num < 300:
        index = 5
    elif num < 350:
        index = 6
    else:
        index = 7
    return index

def countopcode(num):
    opnum = num
    index = 12
    if opnum < 10000:
        index = 0
    elif opnum < 12000:
        index = 1
    elif opnum < 14000:
        index = 2
    elif opnum < 16000:
        index = 3
    elif opnum < 18000:
        index = 4
    elif opnum < 20000:
        index = 5
    elif opnum < 25000:
        index = 6
    elif opnum < 30000:
        index = 7
    elif opnum < 35000:
        index = 8
    else:
        index = 9
    return index

def repeatedyaramodule(ruletype,name):
    yaracmd = "yara rules/"
    targetpath = "sample/"
    yaratype = ruletype
    samplename = name
    recordlist = []
    samplenamelist = []
    count = 0
    # activate yararules to sample
    tmpresult = subprocess.run(yaracmd+yaratype+targetpath+samplename,stdout=subprocess.PIPE, shell=True)
    result = str(tmpresult.stdout).split("\\n")
    if len(result) > 0:
        if "b''" != result[0]:
            count += 1
            samplenamelist.append(samplename)
        if len(result) > 1:
            for k in range(0,len(result)-1):
                if k == 0:
                    rawsplit = result[0].split()
                    if len(recordlist) == 0:
                        recordlist.append([rawsplit[0].replace("b'",""),1])
                    else:
                        flag = 0
                        for item in recordlist:
                            if item[0] == rawsplit[0]:
                                item[1] += 1
                                flag = 1
                                break
                        if flag == 0:
                            recordlist.append([rawsplit[0].replace("b'",""),1])
                else:
                    flag = 0
                    for item in recordlist:
                        if item[0] == rawsplit[0]:
                            item[1] += 1
                            flag = 1
                            break
                    if flag == 0:
                        recordlist.append([rawsplit[0],1])
    return [recordlist,count,samplenamelist]

def percentagecompute(base,ground):
    basic = base
    underground = ground
    if basic == 0:
        return 0
    else:
        if type(underground) == int:
            ratio = float(basic) / underground
        else:
            ratio = float(basic) / len(underground)
        percentage = round(ratio * 100)
        return percentage

if __name__ == "__main__":
    main()
