import sys
import os

def main():
    label_indicator = int(sys.argv[1])
    targetdir = sys.argv[2]
    samplelist = []
    if not os.path.isdir(targetdir):
        print("input path "+targetdir+" is not a directory")
    else:
        samplelist = os.listdir(targetdir)
    with open("training_label.txt",'a',encoding='UTF-8') as outfile:
        if label_indicator == 0:
            for index in range(0,len(samplelist)):
                if index == len(samplelist)-1:
                    outfile.write(samplelist[index]+",0")
                else:
                    outfile.write(samplelist[index]+",0"+"\n")
        elif label_indicator == 1:
            for index in range(0,len(samplelist)):
                if index == len(samplelist)-1:
                    outfile.write(samplelist[index]+",1")
                else:
                    outfile.write(samplelist[index]+",1"+"\n")

if __name__ == "__main__":
    main()
